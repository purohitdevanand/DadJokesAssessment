﻿using DadJokeExerciseAPI.Model;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace DadJokeExerciseAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class RandomJokesController : ControllerBase
    {

        [HttpGet(Name = "RandomJoke")]
        public async Task<RandomJoke> GetRandomJoke()
        {
            var url = string.Format("https://dad-jokes.p.rapidapi.com/random/joke");
            HttpClient httpClient = new();
            httpClient.DefaultRequestHeaders.Add("X-RapidAPI-Key", "c53508c5d7msh8f70ef1e75e8a44p1e50f5jsnf5fbe50ef23f");
            HttpResponseMessage response = httpClient.GetAsync(url).Result;  // Blocking call!
            RandomJoke? rjoke = null;
            if (response.IsSuccessStatusCode)
            {
                try
                {
                    var randomJokeData = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    List<RandomJoke>? lstRJokes = JsonConvert.DeserializeObject<Response>(randomJokeData)?.body;
                    if (lstRJokes != null)
                    {
                        foreach (var item in lstRJokes)
                        {
                            rjoke = new RandomJoke
                            {
                                Id = item.Id,
                                Setup = item.Setup,
                                Punchline = item.Punchline,
                                Type = item.Type
                            };
                        }
                    }
                }
                catch (Exception ex)
                {
                    string messaage = ex.Message;
                    throw;
                }

            }
            return rjoke;
        }
    }
}