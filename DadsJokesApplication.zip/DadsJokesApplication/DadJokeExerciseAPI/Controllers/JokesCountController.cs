﻿using DadJokeExerciseAPI.Model;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace DadJokeExerciseAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class JokesCountController : ControllerBase
    {
        [HttpGet(Name = "JokeCount")]
        public async Task<int?> GetJokeCount()
        {
            var url = string.Format("https://dad-jokes.p.rapidapi.com/joke/count");
            HttpClient httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Add("X-RapidAPI-Key", "c53508c5d7msh8f70ef1e75e8a44p1e50f5jsnf5fbe50ef23f");
            HttpResponseMessage response = httpClient.GetAsync(url).Result;
            int? count = 0;
            if (response.IsSuccessStatusCode)
            {
                try
                {
                    var randomJokeData = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    var jokeCounts = JsonConvert.DeserializeObject<ResponseCount>(randomJokeData)?.body;
                    count = jokeCounts;
                }
                catch (Exception ex)
                {
                    string messaage = ex.Message;
                    throw;
                }

            }
            return count;
        }
    }
}