﻿using Newtonsoft.Json;

namespace DadJokeExerciseAPI.Model
{
    class Response
    {
        public string success { get; set; }
        public List<RandomJoke> body { get; set; }
    }
    public class RandomJoke
    {
        [JsonProperty("_id")] public string Id { get; set; }
        [JsonProperty("punchline")] public string Punchline { get; set; }
        [JsonProperty("setup")] public string Setup { get; set; }
        [JsonProperty("type")] public string Type { get; set; }
    }
    class ResponseCount
    {
        public string success { get; set; }
        public int body { get; set; }
    }
}
